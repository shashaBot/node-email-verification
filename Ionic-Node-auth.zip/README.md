# node-email-verification
Basic Node/express app with email verification and JWT authentication using passport.
